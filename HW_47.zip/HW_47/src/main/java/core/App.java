package core;

public class App {

	public static void main(String[] args) {
		System.out.println(
				"You have to use -cp option [java -cp ./target/HW_46-1.0-jar-with-dependencies.jar core.Main]");
	}
}
